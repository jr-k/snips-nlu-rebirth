from snips_nlu_utils.string import (
    get_shape, hash_str, normalize, remove_diacritics)
from snips_nlu_utils.token import compute_all_ngrams, tokenize, tokenize_light
