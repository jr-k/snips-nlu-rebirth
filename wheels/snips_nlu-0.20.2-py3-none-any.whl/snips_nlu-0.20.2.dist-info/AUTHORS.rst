Snips NLU is written and maintained by Snips.

Development Lead
================

* `Adrien Ball <https://github.com/adrienball>`_
* `Clement Doumouro <https://github.com/clemdoum>`_
