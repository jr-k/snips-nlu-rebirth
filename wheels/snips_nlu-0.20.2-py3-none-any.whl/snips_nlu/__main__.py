from __future__ import print_function, unicode_literals


if __name__ == "__main__":
    from snips_nlu.cli import main
    main()
