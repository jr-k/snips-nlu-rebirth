# coding=utf-8
from __future__ import unicode_literals

from snips_nlu.entity_parser.builtin_entity_parser import BuiltinEntityParser
from snips_nlu.entity_parser.custom_entity_parser import (
    CustomEntityParser, CustomEntityParserUsage)
